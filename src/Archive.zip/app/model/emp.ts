export interface Emp {
    name: string,
    age: number,
    dep: string,
    DOB: Date,
    address: string,
    contact: number
}

