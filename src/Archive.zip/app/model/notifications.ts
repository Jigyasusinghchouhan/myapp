export enum Notifications {
    success = 'File is created',
    error = 'Failed to created file'
}
