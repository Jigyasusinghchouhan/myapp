export interface Employee {
    name: string,
    age: number,
    DOB: Date,
    contact: number,
    department: string
}
