import { Component, Input, OnInit } from '@angular/core';
import { Emp } from 'src/app/model/emp';
import { Notifications } from 'src/app/model/notifications';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  notificationType = Notifications;
  @Input() dataFormParent: any;
  employeeList!: Emp[];
  showNotificationContent: any;
  constructor() { }
  showTable: boolean = false;
  ngOnInit() {
      this.employeeList = this.dataFormParent;
      const orignalData = this.employeeList
    console.log('Before changes', orignalData)

  }
  saveChange() {
    this.showNotificationContent = this.notificationType.success
    console.log('After changes',this.employeeList);
    this.showTable = !this.showTable;
  
  }

}
